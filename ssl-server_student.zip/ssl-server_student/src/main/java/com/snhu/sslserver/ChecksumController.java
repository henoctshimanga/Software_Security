package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@RestController
public class ChecksumController {

    @GetMapping({"/checksum", "/hash"})
    public String getChecksum() {
        String data = "Confidential Financial Data 2025 - ArtemisBank_XYZ#42";
        String checksum = generateChecksum(data, "SHA-256");
        String fullName = "Henoc Mudibu";

        return String.format(
            "<h2>Original Data:</h2> %s" +
            "<br/><h2>SHA-256 Checksum:</h2> %s" +
            "<br/><h2>Processed by:</h2> %s",
            data, checksum, fullName
        );
    }

    private String generateChecksum(String input, String algorithm) {
        try {
            MessageDigest digest = MessageDigest.getInstance(algorithm);
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generating checksum", e);
        }
    }
}